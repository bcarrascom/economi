// Estado de la app + persistencia en archivos JSON dentro de la carpeta elegida.
// Cada colección vive en su propio archivo:
//   movimientos.json · compras.json · tags.json · ajustes.json
// Formato: { app, version, actualizado, data }

import { uid, today, clamp } from './format.js';

const FILES = {
  movimientos: 'movimientos.json',
  compras: 'compras.json',
  tags: 'tags.json',
  ajustes: 'ajustes.json',
};
const VERSION = 1;

export const DEFAULT_AJUSTES = {
  saldoInicial: 0,
  ahorroInicial: 0,
  aporteDefecto: { modo: 'pct', valor: 0 }, // se propone al marcar un ingreso como sueldo
  mostrarIds: false,
  ajustesAhorro: [], // { id, fecha, monto (+/-), nota }
};

export const state = {
  dataDir: null,
  movimientos: [],
  compras: [],
  tags: [],
  ajustes: structuredClone(DEFAULT_AJUSTES),
  error: null,
};

// Archivos que no se pudieron leer: no se sobrescriben para no perder datos.
const bloqueados = new Set();

// ---------- Suscripciones ----------
const subs = new Set();
export const subscribe = (fn) => { subs.add(fn); return () => subs.delete(fn); };
function emit() { for (const fn of subs) fn(); }

let errorHandler = (e) => console.error(e);
export const onError = (fn) => { errorHandler = fn; };

// ---------- Normalización (conserva campos extra que agregues a mano) ----------
const int = (v) => Math.round(Number(v) || 0);

export function normMov(m = {}) {
  return {
    ...m,
    id: m.id || uid(),
    tipo: m.tipo === 'ingreso' ? 'ingreso' : 'gasto',
    fecha: /^\d{4}-\d{2}-\d{2}$/.test(m.fecha || '') ? m.fecha : today(),
    nombre: String(m.nombre ?? ''),
    descripcion: String(m.descripcion ?? ''),
    monto: Math.max(0, int(m.monto)),
    arrepentimiento: clamp(int(m.arrepentimiento), 0, 5),
    tags: Array.isArray(m.tags) ? [...new Set(m.tags)] : [],
    esSueldo: !!m.esSueldo,
    ahorro: {
      modo: m.ahorro?.modo === 'fijo' ? 'fijo' : 'pct',
      valor: Math.max(0, Number(m.ahorro?.valor) || 0),
    },
    esInversion: !!m.esInversion,
    desdeAhorro: !!m.desdeAhorro,
    inversion: { ingresoId: m.inversion?.ingresoId || null },
    origen: m.origen || null,
    creado: m.creado || new Date().toISOString(),
    editado: m.editado || null,
  };
}

export function normCompra(c = {}) {
  return {
    ...c,
    id: c.id || uid(),
    nombre: String(c.nombre ?? ''),
    descripcion: String(c.descripcion ?? ''),
    costo: Math.max(0, int(c.costo)),
    tags: Array.isArray(c.tags) ? [...new Set(c.tags)] : [],
    esAhorro: !!c.esAhorro,
    creado: c.creado || new Date().toISOString(),
  };
}

export function normTag(t = {}) {
  return {
    ...t,
    id: t.id || uid(),
    nombre: String(t.nombre ?? '').trim() || 'Sin nombre',
    color: /^#[0-9a-f]{3,8}$/i.test(t.color || '') ? t.color : '#ffffff',
  };
}

// ---------- Índices ----------
let tagIdx = new Map();
const rebuild = () => { tagIdx = new Map(state.tags.map((t) => [t.id, t])); };
export const tagById = (id) => tagIdx.get(id);
export const getMov = (id) => state.movimientos.find((m) => m.id === id);

// ---------- Carga ----------
const itemsOf = (d) => (Array.isArray(d) ? d : Array.isArray(d?.data) ? d.data : []);

async function readAll() {
  const raw = {};
  const faltantes = [];
  const errores = [];
  bloqueados.clear();

  for (const [key, file] of Object.entries(FILES)) {
    const r = await window.api.read(file);
    if (!r.ok) {
      errores.push(`${file}: ${r.error}`);
      bloqueados.add(key);
    } else if (r.missing) {
      faltantes.push(key);
    }
    raw[key] = r.ok ? r.data : null;
  }

  state.error = errores.length ? errores.join('\n') : null;
  state.movimientos = itemsOf(raw.movimientos).map(normMov);
  state.compras = itemsOf(raw.compras).map(normCompra);
  state.tags = itemsOf(raw.tags).map(normTag);

  const aj = raw.ajustes?.data ?? raw.ajustes ?? {};
  state.ajustes = {
    ...structuredClone(DEFAULT_AJUSTES),
    ...aj,
    aporteDefecto: { ...DEFAULT_AJUSTES.aporteDefecto, ...(aj.aporteDefecto || {}) },
    ajustesAhorro: Array.isArray(aj.ajustesAhorro) ? aj.ajustesAhorro : [],
  };
  rebuild();
  return faltantes;
}

/** Devuelve false si todavía no hay carpeta elegida. */
export async function load() {
  const cfg = await window.api.getConfig();
  state.dataDir = cfg.dataDir;
  if (!state.dataDir) return false;
  const faltantes = await readAll();
  if (faltantes.length) persist(...faltantes); // inicializa archivos nuevos
  if (!state.error) window.api.backup().catch(() => {});
  return true;
}

export async function reload() {
  await readAll();
  emit();
}

export async function chooseFolder() {
  const dir = await window.api.chooseFolder();
  if (!dir) return false;
  state.dataDir = dir;
  const faltantes = await readAll();
  if (faltantes.length) persist(...faltantes);
  emit();
  return true;
}

// ---------- Persistencia (cola secuencial) ----------
let cola = Promise.resolve();

function persist(...keys) {
  const aGuardar = keys.filter((k) => {
    if (bloqueados.has(k)) {
      errorHandler(new Error(`${FILES[k]} no se pudo leer al abrir; no se sobrescribirá. Revisa el archivo y recarga.`));
      return false;
    }
    return true;
  });
  cola = cola.then(async () => {
    for (const k of aGuardar) {
      const payload = { app: 'app-finanzas', version: VERSION, actualizado: new Date().toISOString(), data: state[k] };
      const r = await window.api.write(FILES[k], payload);
      if (!r.ok) throw new Error(`No se pudo guardar ${FILES[k]}: ${r.error}`);
    }
  }).catch((e) => errorHandler(e));
  return cola;
}

const upsert = (arr, item) => {
  const i = arr.findIndex((x) => x.id === item.id);
  if (i >= 0) arr[i] = item; else arr.push(item);
};

// ---------- Movimientos ----------
export function saveMovimiento(m) {
  const existe = state.movimientos.some((x) => x.id === m.id);
  const n = normMov({ ...m, editado: existe ? new Date().toISOString() : m.editado });
  upsert(state.movimientos, n);
  persist('movimientos');
  emit();
  return n;
}

/** Ingreso creado automáticamente como retorno de esta inversión (si existe). */
export function autoRetorno(g) {
  const id = g?.inversion?.ingresoId;
  const ing = id ? getMov(id) : null;
  return ing && ing.origen?.tipo === 'inversion' && ing.origen.gastoId === g.id ? ing : null;
}

/** Ingresos disponibles para vincular a una inversión. */
export function ingresosVinculables(gastoId) {
  const usados = new Set(state.movimientos
    .filter((g) => g.id !== gastoId && g.inversion?.ingresoId)
    .map((g) => g.inversion.ingresoId));
  return state.movimientos
    .filter((m) => m.tipo === 'ingreso' && !usados.has(m.id)
      && !(m.origen?.tipo === 'inversion' && m.origen.gastoId !== gastoId))
    .sort((a, b) => b.fecha.localeCompare(a.fecha));
}

/**
 * Define el resultado de una inversión.
 * spec: { modo: 'pendiente' } | { modo: 'vincular', ingresoId } | { modo: 'manual', monto, fecha }
 * "manual" crea (o actualiza) un ingreso automático con el monto recuperado.
 */
export function resolverInversion(gastoId, spec) {
  const g = getMov(gastoId);
  if (!g) return;
  const auto = autoRetorno(g);

  if (spec.modo === 'manual') {
    if (auto) {
      auto.monto = Math.max(0, int(spec.monto));
      auto.fecha = spec.fecha || today();
      auto.editado = new Date().toISOString();
    } else {
      const ing = normMov({
        tipo: 'ingreso',
        fecha: spec.fecha || today(),
        nombre: `Retorno: ${g.nombre}`,
        monto: spec.monto,
        tags: [...g.tags],
        origen: { tipo: 'inversion', gastoId: g.id },
      });
      state.movimientos.push(ing);
      g.inversion.ingresoId = ing.id;
    }
  } else {
    if (auto) state.movimientos = state.movimientos.filter((x) => x.id !== auto.id);
    g.inversion.ingresoId = spec.modo === 'vincular' ? spec.ingresoId : null;
  }
  persist('movimientos');
  emit();
}

export function deleteMovimiento(id) {
  const m = getMov(id);
  if (!m) return;
  const ids = new Set([id]);
  const auto = autoRetorno(m);
  if (auto) ids.add(auto.id);
  // Si se borra un ingreso usado como retorno, la inversión vuelve a "pendiente".
  for (const g of state.movimientos) {
    if (g.inversion?.ingresoId && ids.has(g.inversion.ingresoId) && !ids.has(g.id)) g.inversion.ingresoId = null;
  }
  state.movimientos = state.movimientos.filter((x) => !ids.has(x.id));
  persist('movimientos');
  emit();
}

// ---------- Tags ----------
export function saveTag(t) {
  const n = normTag(t);
  upsert(state.tags, n);
  rebuild();
  persist('tags');
  emit();
  return n;
}

export function deleteTag(id) {
  state.tags = state.tags.filter((t) => t.id !== id);
  for (const m of state.movimientos) m.tags = m.tags.filter((x) => x !== id);
  for (const c of state.compras) c.tags = c.tags.filter((x) => x !== id);
  rebuild();
  persist('tags', 'movimientos', 'compras');
  emit();
}

export function usoTag(id) {
  const movs = state.movimientos.filter((m) => m.tags.includes(id));
  return {
    usos: movs.length + state.compras.filter((c) => c.tags.includes(id)).length,
    gastado: movs.filter((m) => m.tipo === 'gasto').reduce((a, m) => a + m.monto, 0),
    ingresado: movs.filter((m) => m.tipo === 'ingreso').reduce((a, m) => a + m.monto, 0),
    enLista: state.compras.filter((c) => c.tags.includes(id)).reduce((a, c) => a + c.costo, 0),
  };
}

// ---------- Lista de compras ----------
export function saveCompra(c) {
  const n = normCompra(c);
  upsert(state.compras, n);
  persist('compras');
  emit();
  return n;
}

export function deleteCompra(id) {
  state.compras = state.compras.filter((c) => c.id !== id);
  persist('compras');
  emit();
}

/** Pasa un ítem de la lista a gastos. No se puede deshacer directamente. */
export function comprar(id, fecha = today()) {
  const c = state.compras.find((x) => x.id === id);
  if (!c) return null;
  const g = normMov({
    tipo: 'gasto',
    fecha,
    nombre: c.nombre,
    descripcion: c.descripcion,
    monto: c.costo,
    tags: [...c.tags],
    desdeAhorro: c.esAhorro,
    origen: { tipo: 'compra', compraId: c.id, esAhorro: c.esAhorro, agregadoALista: c.creado },
  });
  state.movimientos.push(g);
  state.compras = state.compras.filter((x) => x.id !== id);
  persist('movimientos', 'compras');
  emit();
  return g;
}

// ---------- Ajustes ----------
export function updateAjustes(patch) {
  state.ajustes = { ...state.ajustes, ...patch };
  persist('ajustes');
  emit();
}

export function addAjusteAhorro({ fecha, monto, nota }) {
  state.ajustes.ajustesAhorro.push({ id: uid(), fecha: fecha || today(), monto: int(monto), nota: nota || '' });
  persist('ajustes');
  emit();
}

export function deleteAjusteAhorro(id) {
  state.ajustes.ajustesAhorro = state.ajustes.ajustesAhorro.filter((a) => a.id !== id);
  persist('ajustes');
  emit();
}
