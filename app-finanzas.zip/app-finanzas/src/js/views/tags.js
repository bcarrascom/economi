// Tags: crear, editar y eliminar las categorías.

import * as store from '../store.js';
import { state } from '../store.js';
import { clp, esc } from '../format.js';
import { icon } from '../icons.js';
import { tagPill, confirmDialog, toast } from '../ui.js';
import { openTagForm } from '../forms/tag-form.js';

export const meta = { id: 'tags', title: 'Tags', icon: 'tag' };

export function render(root, { first }) {
  const tags = [...state.tags].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
  root.innerHTML = `
    <header class="page-head">
      <div><h1>Tags</h1><p class="subtitle">Etiquetas para organizar, filtrar y graficar</p></div>
      <div class="spacer"></div>
      <button class="ibtn primary" data-act="nuevo" data-tip="Nuevo tag">${icon('plus')}</button>
    </header>
    ${tags.length ? `<section class="tag-grid">${tags.map((t, i) => {
      const u = store.usoTag(t.id);
      return `
        <div class="card tag-card ${first ? 'anim' : ''}" style="--c:${esc(t.color)};--i:${i}" data-id="${t.id}">
          <div class="tag-card-head">${tagPill(t)}<span class="spacer"></span>
            <button class="ibtn ghost xs" data-act="edit" data-tip="Editar">${icon('edit')}</button>
            <button class="ibtn ghost xs danger" data-act="del" data-tip="Eliminar">${icon('trash')}</button>
          </div>
          <dl class="tag-stats">
            <div><dt>Gastado</dt><dd>${clp(u.gastado)}</dd></div>
            <div><dt>Ingresado</dt><dd>${clp(u.ingresado)}</dd></div>
            <div><dt>En lista</dt><dd>${clp(u.enLista)}</dd></div>
            <div><dt>Usos</dt><dd>${u.usos}</dd></div>
          </dl>
        </div>`;
    }).join('')}</section>`
    : `<div class="card empty">Aún no tienes tags. Crea el primero con ${icon('plus', 'inline')}; también puedes crearlos al registrar un movimiento.</div>`}`;

  root.querySelector('[data-act="nuevo"]').onclick = () => openTagForm();
  root.querySelector('.tag-grid')?.addEventListener('click', async (e) => {
    const card = e.target.closest('.tag-card');
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (!card || !act) return;
    const t = store.tagById(card.dataset.id);
    if (act === 'edit') openTagForm(t);
    if (act === 'del') {
      const u = store.usoTag(t.id);
      const ok = await confirmDialog({
        title: 'Eliminar tag',
        message: `Se eliminará ${tagPill(t)}${u.usos ? ` y se quitará de <b>${u.usos}</b> ${u.usos === 1 ? 'elemento' : 'elementos'}` : ''}.`,
        confirmIcon: 'trash',
        danger: true,
      });
      if (ok) { store.deleteTag(t.id); toast('Tag eliminado'); }
    }
  });
}
